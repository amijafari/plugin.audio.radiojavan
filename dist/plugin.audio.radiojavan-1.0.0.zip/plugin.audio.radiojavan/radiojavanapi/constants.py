API_DOMAIN = "https://rjappapi.me/api2/{}"
BASE_HEADERS = {
    'Accept':'*/*',
    'Accept-Language':'en-US',
    'Accept-Encoding':'gzip, deflate',
    'Host':'rjappapi.me',
    'Connection':'keep-alive',
    'User-Agent':'Radio Javan/3.7.8 (Windows_NT 10.0.19043) com.RadioJavan.RJ.desktop',
}
