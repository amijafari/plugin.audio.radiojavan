# Radio Javan Kodi Plugin
This is a Kodi plugin for the Iranian Music Application Radio Javan. This is a work in progress and now some general features is implemented.

## Requirements
This plugin uses [RadioJavanAPI](https://github.com/xHossein/radiojavanapi/).  
to install the module, ssh to Kodi server and run the following commands:
```
$ sudo apt install python3-pip 
$ sudo pip install radiojavanapi
```

## Installation 
* 1- Download plugin as zip file
* 2- Transfer downloaded file to Kodi
* 3- Goto Add-ons
* 4- Goto Install from zip file
* 5- Select downloaded file to install

